Steps to Execute the Tests
=============================
1. Create a workspace in Postman
2. Import the collections:
   Data_Driven_Sogeti_API.postman_collection
   Sogeti_API.postman_collection
3. To Run Data-Driven Collection;
   3.1 Right Click on Collection Name and Select Run Collection
   3.2 Upload TestData.csv file 
   3.3 Click Run
API Test Document is attached for reference.
   






